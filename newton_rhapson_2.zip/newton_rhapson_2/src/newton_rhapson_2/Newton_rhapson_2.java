/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newton_rhapson_2;

import java.util.Scanner;

/**
 *
 * @author gabya
 */
public class Newton_rhapson_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entrada = new Scanner(System.in);
        
        int iter=1;
        double xn,xr,y,d,m,ma,tol,e;
    }
    
}
